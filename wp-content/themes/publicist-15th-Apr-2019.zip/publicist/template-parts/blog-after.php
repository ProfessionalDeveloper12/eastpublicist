			</div><!-- content-area + page_layout_css -->

			<?php get_sidebar(); ?>

		</div><!-- .div for row /- -->

	</div><!-- .container /- -->
	
</main><!-- .site-main -->

<?php get_footer(); ?>