<?php
/* Include all individual CPT. */
$prefix_cpt = "cpt_";

/* Case Histories */
require_once( $prefix_cpt . "case_histories.php" );
?>